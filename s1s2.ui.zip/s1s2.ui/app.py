from flask import Flask, render_template, jsonify, request
from datetime import datetime
import S1S2  # 导入你的逻辑文件

app = Flask(__name__)

# 初始化 S1S2 中的存储和务
store = S1S2.ReminderStore("reminders.json")
service = S1S2.ReminderService(store)

@app.route('/')
def index():
    return render_template('index.html')

# --- 提醒事项 (S1) 接口 ---
@app.route('/api/reminders', methods=['GET'])
def get_reminders():
    reminders = store.load()
    return jsonify([S1S2.asdict(r) for r in reminders])

@app.route('/api/reminders', methods=['POST'])
def add_reminder():
    data = request.json
    try:
        new_rem = S1S2.Reminder(
            category=data['category'],
            name=data['name'],
            time_hhmm=data['time_hhmm']
        )
        store.add(new_rem)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

@app.route('/api/reminders/toggle/<int:index>', methods=['POST'])
def toggle_reminder(index):
    store.toggle_at(index)
    return jsonify({"status": "success"})

@app.route('/api/reminders/<int:index>', methods=['DELETE'])
def delete_reminder(index):
    store.delete_at(index)
    return jsonify({"status": "success"})

@app.route('/api/check', methods=['GET'])
def check_reminders():
    due = []
    # 使用你定义的 tick 方法，它会自动调用 mark_alerted
    service.tick(lambda r: due.append(S1S2.asdict(r)))
    return jsonify(due)

# --- 健康记录 (S2) 接口 ---
@app.route('/api/health', methods=['GET'])
def get_health():
    return jsonify(S1S2.load_records())

@app.route('/api/health', methods=['POST'])
def add_health():
    status = request.json.get('status')
    records = S1S2.load_records()
    entry = {"date": datetime.now().strftime("%Y-%m-%d %H:%M"), "status": status}
    records.append(entry)
    S1S2.save_records(records)
    return jsonify({"status": "success"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)