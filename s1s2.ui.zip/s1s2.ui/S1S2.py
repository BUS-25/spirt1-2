from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Callable, List, Literal, Optional


# =========================
# S1: Reminder System
# =========================
Category = Literal["medication", "activity"]


@dataclass
class Reminder:
    category: Category
    name: str
    time_hhmm: str
    enabled: bool = True
    frequency: str = "daily"
    icon: str = ""
    last_alert_date: Optional[str] = None

    def validate(self) -> None:
        if self.category not in ("medication", "activity"):
            raise ValueError("Invalid category")
        if not self.name.strip():
            raise ValueError("Name is required")
        # Validate HH:MM
        datetime.strptime(self.time_hhmm, "%H:%M")

    def is_due(self, now: datetime) -> bool:
        if not self.enabled:
            return False
        if now.strftime("%H:%M") != self.time_hhmm:
            return False
        today = now.strftime("%Y-%m-%d")
        return self.last_alert_date != today

    def mark_alerted(self, now: datetime) -> None:
        self.last_alert_date = now.strftime("%Y-%m-%d")


class ReminderStore:
    def __init__(self, path: str | Path = "reminders.json"):
        self.path = Path(path)

    def load(self) -> List[Reminder]:
        if not self.path.exists():
            return []
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        items: List[Reminder] = []
        for obj in raw:
            r = Reminder(**obj)
            r.validate()
            if not r.icon:
                r.icon = "💊" if r.category == "medication" else "🏃"
            items.append(r)
        return items

    def save(self, reminders: List[Reminder]) -> None:
        for r in reminders:
            r.validate()
            if not r.icon:
                r.icon = "💊" if r.category == "medication" else "🏃"
        self.path.write_text(
            json.dumps([asdict(r) for r in reminders], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def add(self, reminder: Reminder) -> List[Reminder]:
        reminders = self.load()
        reminder.validate()
        if not reminder.icon:
            reminder.icon = "💊" if reminder.category == "medication" else "🏃"
        reminders.append(reminder)
        self.save(reminders)
        return reminders

    def delete_at(self, index: int) -> List[Reminder]:
        reminders = self.load()
        if index < 0 or index >= len(reminders):
            raise IndexError("Invalid index")
        reminders.pop(index)
        self.save(reminders)
        return reminders

    def toggle_at(self, index: int) -> List[Reminder]:
        reminders = self.load()
        if index < 0 or index >= len(reminders):
            raise IndexError("Invalid index")
        reminders[index].enabled = not reminders[index].enabled
        self.save(reminders)
        return reminders


class ReminderService:
    def __init__(self, store: ReminderStore):
        self.store = store

    def due_reminders(self, now: Optional[datetime] = None) -> List[Reminder]:
        now = now or datetime.now()
        reminders = self.store.load()
        return [r for r in reminders if r.is_due(now)]

    def mark_alerted(self, reminder: Reminder, now: Optional[datetime] = None) -> None:
        now = now or datetime.now()
        reminders = self.store.load()
        for r in reminders:
            if (
                r.category == reminder.category
                and r.name == reminder.name
                and r.time_hhmm == reminder.time_hhmm
                and r.frequency == reminder.frequency
            ):
                r.mark_alerted(now)
        self.store.save(reminders)

    def filter_by(self, kind: Literal["medication", "activity", "all"]) -> List[Reminder]:
        reminders = self.store.load()
        if kind == "all":
            return reminders
        return [r for r in reminders if r.category == kind]

    def tick(self, notify: Callable[[Reminder], None], now: Optional[datetime] = None) -> int:
        now = now or datetime.now()
        due = self.due_reminders(now)
        if not due:
            return 0
        for r in due:
            notify(r)
            self.mark_alerted(r, now)
        return len(due)


# =========================
# S2: Daily Health Input
# =========================
DATA_FILE = "daily_health_records.json"
HEALTH_OPTIONS = ["Good", "Okay", "Tired", "Pain", "Unwell"]


def load_records() -> list:
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def save_records(records: list) -> None:
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(records, file, indent=2, ensure_ascii=False)


def record_health_status_cli() -> None:
    print("\n=== Daily Health Input (S2) ===")
    print("Please select your health status for today:")
    for i, option in enumerate(HEALTH_OPTIONS, start=1):
        print(f"{i}. {option}")

    while True:
        try:
            choice = int(input("\nEnter your choice (1-5): ").strip())
            if 1 <= choice <= len(HEALTH_OPTIONS):
                selected_status = HEALTH_OPTIONS[choice - 1]
                break
            print("Invalid option. Please select a number between 1 and 5.")
        except ValueError:
            print("Invalid input. Please enter a number.")

    records = load_records()
    entry = {"date": datetime.now().strftime("%Y-%m-%d"), "status": selected_status}
    records.append(entry)
    save_records(records)

    print("\n✔ Your health status has been recorded successfully!")
    print(f"Date: {entry['date']}")
    print(f"Selected Status: {entry['status']}\n")


def view_recent_health_records(limit: int = 10) -> None:
    records = load_records()
    if not records:
        print("\nNo health records found.\n")
        return
    print("\n=== Recent Health Records ===")
    for entry in records[-limit:]:
        print(f"{entry.get('date', '')} — {entry.get('status', '')}")
    print("")


# =========================
# Integrated CLI App (Sprint 1 demo)
# =========================
def notify_console(reminder: Reminder) -> None:
    now = datetime.now().strftime("%H:%M")
    print(f"\n⏰ [{now}] {reminder.icon} REMINDER: {reminder.category.upper()} — {reminder.name} (at {reminder.time_hhmm})")


def list_reminders(service: ReminderService) -> None:
    reminders = service.filter_by("all")
    if not reminders:
        print("\nNo reminders yet.\n")
        return
    print("\n=== Reminders (S1) ===")
    for i, r in enumerate(reminders):
        status = "ON" if r.enabled else "OFF"
        print(f"{i}. {r.icon} {r.category} | {r.name} | {r.time_hhmm} | {status}")
    print("")


def add_reminder_cli(store: ReminderStore) -> None:
    print("\n=== Add Reminder (S1) ===")
    cat = input("Category (medication/activity): ").strip().lower()
    if cat not in ("medication", "activity"):
        print("Invalid category.\n")
        return
    name = input("Name (e.g., Aspirin / 10-min walk): ").strip()
    time_hhmm = input("Time (HH:MM, 24h, e.g., 09:00): ").strip()

    try:
        reminder = Reminder(category=cat, name=name, time_hhmm=time_hhmm)
        store.add(reminder)
        print("✔ Reminder added.\n")
    except Exception as e:
        print(f"❌ Failed to add reminder: {e}\n")


def delete_reminder_cli(store: ReminderStore) -> None:
    idx = input("Enter reminder index to delete: ").strip()
    try:
        i = int(idx)
        store.delete_at(i)
        print("✔ Reminder deleted.\n")
    except Exception as e:
        print(f"❌ Failed to delete reminder: {e}\n")


def toggle_reminder_cli(store: ReminderStore) -> None:
    idx = input("Enter reminder index to toggle ON/OFF: ").strip()
    try:
        i = int(idx)
        store.toggle_at(i)
        print("✔ Reminder toggled.\n")
    except Exception as e:
        print(f"❌ Failed to toggle reminder: {e}\n")


def run_due_checker(service: ReminderService) -> None:
    """
    Simple demo loop: checks every 10 seconds.
    For a quick demo, set a reminder to the next minute (e.g., current time + 1 minute).
    """
    print("\n=== Reminder Checker Running (press Ctrl+C to stop) ===")
    print("Tip: Set a reminder time to the next minute for demo.\n")
    try:
        while True:
            fired = service.tick(notify_console)
            # optional: show heartbeat only when fired
            if fired > 0:
                print(f"✔ {fired} reminder(s) fired.\n")
            time.sleep(10)
    except KeyboardInterrupt:
        print("\nStopped.\n")


def main():
    store = ReminderStore("reminders.json")
    service = ReminderService(store)

    while True:
        print("======== ElderCare Connect (Sprint 1) ========")
        print("S1: Reminder System")
        print("  1) List reminders")
        print("  2) Add reminder")
        print("  3) Toggle reminder ON/OFF")
        print("  4) Delete reminder")
        print("  5) Run reminder checker (demo)")
        print("S2: Daily Health Input")
        print("  6) Record today's health status")
        print("  7) View recent health records")
        print("  0) Exit")
        choice = input("Select: ").strip()

        if choice == "1":
            list_reminders(service)
        elif choice == "2":
            add_reminder_cli(store)
        elif choice == "3":
            list_reminders(service)
            toggle_reminder_cli(store)
        elif choice == "4":
            list_reminders(service)
            delete_reminder_cli(store)
        elif choice == "5":
            run_due_checker(service)
        elif choice == "6":
            record_health_status_cli()
        elif choice == "7":
            view_recent_health_records()
        elif choice == "0":
            print("Bye!")
            break
        else:
            print("Invalid choice.\n")


if __name__ == "__main__":
    main()