from flask import Flask, render_template, jsonify, request, session, Response
from datetime import datetime
import os, csv, io
import login, s1, s2

app = Flask(__name__)
app.secret_key = "eldercare_secure_key_888"

# 初始化
db = login.Database("users_db.json")
auth = login.AuthService(db)
rem_store = s1.ReminderStore("reminders.json")
rem_service = s1.ReminderService(rem_store)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json
    try:
        auth.register_elderly(id=data['id'], password=data['password'], name=data['name'])
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/auth/login', methods=['POST'])
def user_login():
    data = request.json
    try:
        user_info = auth.login_elderly(id=data['id'], password=data['password'])
        session['user'] = user_info
        return jsonify({"status": "success", "user": user_info})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/reminders', methods=['GET', 'POST'])
def handle_reminders():
    if 'user' not in session: return jsonify([]), 401
    if request.method == 'POST':
        data = request.json
        r = s1.Reminder(
            category=data['category'],
            name=data['name'],
            time_hhmm=data['time_hhmm'],
            frequency=data.get('frequency', 'Daily')
        )
        rem_store.add(r)
        return jsonify({"status": "success"})
    return jsonify([s1.asdict(r) for r in rem_store.load()])

@app.route('/api/reminders/toggle/<int:index>', methods=['POST'])
def toggle_reminder(index):
    rem_store.toggle_at(index)
    return jsonify({"status": "success"})

@app.route('/api/reminders/<int:index>', methods=['DELETE'])
def delete_reminder(index):
    rem_store.delete_at(index)
    return jsonify({"status": "success"})

@app.route('/api/check', methods=['GET'])
def check_reminders():
    due = []
    rem_service.tick(lambda r: due.append(s1.asdict(r)))
    return jsonify(due)

@app.route('/api/health', methods=['GET', 'POST'])
def handle_health():
    if 'user' not in session: return jsonify([]), 401
    if request.method == 'POST':
        data = request.json
        records = s2.load_records()
        records.append({
            "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "status": data['status'],
            "heart_rate": data.get('heart_rate', '--'),
            "blood_pressure": data.get('blood_pressure', '--')
        })
        s2.save_records(records)
        return jsonify({"status": "success"})
    return jsonify(s2.load_records())

@app.route('/api/export', methods=['GET'])
def export_data():
    records = s2.load_records()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Date', 'Status/Mood', 'Heart Rate', 'Blood Pressure'])
    for r in records:
        writer.writerow([r.get('date'), r.get('status'), r.get('heart_rate'), r.get('blood_pressure')])
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-disposition": "attachment; filename=health_report.csv"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)