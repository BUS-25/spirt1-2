
from __future__ import annotations
import json
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Callable, List, Literal, Optional

# 扩展分类：增加 exercise 和 others
Category = Literal["medication", "exercise", "others"]

@dataclass
class Reminder:
    category: Category
    name: str
    time_hhmm: str
    enabled: bool = True
    frequency: str = "Daily"
    icon: str = ""
    last_alert_date: Optional[str] = None

    def validate(self) -> None:
        if self.category not in ("medication", "exercise", "others"):
            raise ValueError(f"Invalid category: {self.category}")
        if not self.name.strip():
            raise ValueError("Name is required")
        datetime.strptime(self.time_hhmm, "%H:%M")

    def is_due(self, now: datetime) -> bool:
        if not self.enabled:
            return False
        if now.strftime("%H:%M") != self.time_hhmm:
            return False
        today = now.strftime("%Y-%m-%d")
        return self.last_alert_date != today

    def mark_alerted(self, now: datetime) -> None:
        self.last_alert_date = now.strftime("%Y-%m-%d")

class ReminderStore:
    def __init__(self, path: str | Path = "reminders.json"):
        self.path = Path(path)

    def load(self) -> List[Reminder]:
        if not self.path.exists():
            return []
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        items: List[Reminder] = []
        for obj in raw:
            r = Reminder(**obj)
            if not r.icon:
                if r.category == "medication": r.icon = "💊"
                elif r.category == "exercise": r.icon = "🏃"
                else: r.icon = "🔔"
            items.append(r)
        return items

    def save(self, reminders: List[Reminder]) -> None:
        self.path.write_text(
            json.dumps([asdict(r) for r in reminders], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def add(self, reminder: Reminder) -> List[Reminder]:
        reminders = self.load()
        reminder.validate()
        reminders.append(reminder)
        self.save(reminders)
        return reminders

    def delete_at(self, index: int) -> List[Reminder]:
        reminders = self.load()
        if 0 <= index < len(reminders):
            reminders.pop(index)
            self.save(reminders)
        return reminders

    def toggle_at(self, index: int) -> List[Reminder]:
        reminders = self.load()
        if 0 <= index < len(reminders):
            reminders[index].enabled = not reminders[index].enabled
            self.save(reminders)
        return reminders

class ReminderService:
    def __init__(self, store: ReminderStore):
        self.store = store

    def due_reminders(self, now: Optional[datetime] = None) -> List[Reminder]:
        now = now or datetime.now()
        reminders = self.store.load()
        return [r for r in reminders if r.is_due(now)]

    def tick(self, notify: Callable[[Reminder], None], now: Optional[datetime] = None) -> int:
        now = now or datetime.now()
        due = self.due_reminders(now)
        for r in due:
            notify(r)
            # 标记已提醒
            all_rem = self.store.load()
            for item in all_rem:
                if item.name == r.name and item.time_hhmm == r.time_hhmm:
                    item.mark_alerted(now)
            self.store.save(all_rem)
        return len(due)