from __future__ import annotations
import json
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Callable, List, Literal, Optional

Category = Literal["medication", "exercise", "others"]

@dataclass
class Reminder:
    category: Category
    name: str
    time_hhmm: str
    enabled: bool = True
    frequency: str = "Daily"
    icon: str = ""
    last_alert_date: Optional[str] = None

    def validate(self) -> None:
        if self.category not in ("medication", "exercise", "others"):
            raise ValueError(f"Invalid category")
        if not self.name.strip():
            raise ValueError("Name is required")
        datetime.strptime(self.time_hhmm, "%H:%M")

    def is_due(self, now: datetime) -> bool:
        if not self.enabled: return False
        if now.strftime("%H:%M") != self.time_hhmm: return False
        return self.last_alert_date != now.strftime("%Y-%m-%d")

    def mark_alerted(self, now: datetime) -> None:
        self.last_alert_date = now.strftime("%Y-%m-%d")

class ReminderStore:
    def __init__(self, path: str | Path = "reminders.json"):
        self.path = Path(path)

    def load(self) -> List[Reminder]:
        if not self.path.exists(): return []
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        items = []
        for obj in raw:
            r = Reminder(**obj)
            if not r.icon:
                r.icon = "💊" if r.category == "medication" else "🏃" if r.category == "exercise" else "🔔"
            items.append(r)
        return items

    def save(self, reminders: List[Reminder]) -> None:
        self.path.write_text(json.dumps([asdict(r) for r in reminders], ensure_ascii=False, indent=2))

    def add(self, r: Reminder):
        items = self.load(); r.validate(); items.append(r); self.save(items)

    def delete_at(self, index: int):
        items = self.load()
        if 0 <= index < len(items): items.pop(index); self.save(items)

    def toggle_at(self, index: int):
        items = self.load()
        if 0 <= index < len(items): items[index].enabled = not items[index].enabled; self.save(items)

class ReminderService:
    def __init__(self, store: ReminderStore): self.store = store
    def tick(self, notify: Callable[[Reminder], None]):
        now = datetime.now()
        reminders = self.store.load()
        for r in [rem for rem in reminders if rem.is_due(now)]:
            notify(r)
            r.mark_alerted(now)
        self.store.save(reminders)