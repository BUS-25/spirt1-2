import json
import os

class Database:

    def __init__(self, filepath):
        self.filepath = filepath
        if not os.path.exists(filepath):
            with open(filepath, 'w') as f:
                json.dump({}, f)

    def load(self):
        with open(self.filepath, 'r') as f:
            return json.load(f)

    def save(self, data):
        with open(self.filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def userExists(self, user_id):
        data = self.load()
        return user_id in data


class AuthService:

    def __init__(self, db):
        self.db = db

    # 🔹 新统一注册函数
    def register_user(self, id, password, name,
                      role="elder",
                      linked_elderly_id=None):

        data = self.db.load()

        if id in data:
            raise Exception("User already exists")

        data[id] = {
            "id": id,
            "password": password,
            "name": name,
            "role": role,
            "linked_elderly_id": linked_elderly_id
        }

        self.db.save(data)

    # 🔹 新统一登录函数
    def login_user(self, id, password):

        data = self.db.load()

        if id not in data:
            raise Exception("User not found")

        user = data[id]

        if user["password"] != password:
            raise Exception("Incorrect password")

        # 返回安全数据（不带密码）
        return {
            "id": user["id"],
            "name": user["name"],
            "role": user.get("role", "elder"),
            "linked_elderly_id": user.get("linked_elderly_id")
        }