from flask import Flask, request, jsonify, session, render_template, make_response
import json
import os
import csv
from io import StringIO
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "eldercare-secret"

# 文件路径配置
DATA_FILE = "daily_health_records.json"
USERS_FILE = "users_db.json"
REMINDERS_FILE = "reminders.json"


# =========================
# 通用工具函数
# =========================
def load_json(file_path, default_factory=list):
    if not os.path.exists(file_path):
        return default_factory()
    with open(file_path, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except:
            return default_factory()


def save_json(file_path, data):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def get_target_id(user):
    """精准获取当前应该操作的老人 ID"""
    role = user.get("role")
    if role in ["elder", "elderly"]:
        return user.get("id")
    elif role == "carer":
        return user.get("linked_elderly_id", "")
    return ""


# =========================
# 路由逻辑
# =========================

@app.route("/")
def home():
    return render_template("index.html")


# --- 健康记录 API ---
@app.route("/api/health", methods=["GET", "POST"])
def health_api():
    if "user" not in session: return jsonify({"status": "error", "message": "Not logged in"})
    user = session["user"]

    if request.method == "POST":
        if user.get("role") not in ["elder", "elderly"]:
            return jsonify({"status": "error", "message": "Access denied"})

        data = request.json
        all_records = load_json(DATA_FILE)

        record = {
            "user_id": user["id"],
            "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "status": data.get("status"),
            "heart_rate": data.get("heart_rate"),
            "blood_pressure": data.get("blood_pressure")
        }
        all_records.append(record)
        save_json(DATA_FILE, all_records)
        return jsonify({"status": "success"})

    if request.method == "GET":
        target_id = get_target_id(user)
        all_records = load_json(DATA_FILE)
        user_records = [r for r in all_records if r.get("user_id") == target_id]
        return jsonify(user_records)


# --- 导出 CSV API ---
@app.route("/api/export")
def export_csv():
    if "user" not in session: return "Unauthorized", 401
    user = session["user"]
    target_id = get_target_id(user)

    all_records = load_json(DATA_FILE)
    user_records = [r for r in all_records if r.get("user_id") == target_id]

    si = StringIO()
    cw = csv.writer(si)
    cw.writerow(['Date', 'Mood Status', 'Heart Rate (bpm)', 'Blood Pressure (mmHg)'])
    for r in user_records:
        cw.writerow([r.get('date'), r.get('status'), r.get('heart_rate'), r.get('blood_pressure')])

    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = f"attachment; filename=health_records_{target_id}.csv"
    output.headers["Content-type"] = "text/csv"
    return output


# --- 提醒事项 API (双端通用 + 新增 history 字典) ---
@app.route("/api/reminders", methods=["GET", "POST"])
def reminders_api():
    if "user" not in session: return jsonify([])
    user = session["user"]
    target_id = get_target_id(user)

    all_reminders = load_json(REMINDERS_FILE)

    if request.method == "POST":
        if not target_id:
            return jsonify({"status": "error", "message": "No linked elder ID found."})

        data = request.json
        data["id"] = int(datetime.now().timestamp() * 1000) % 10000000
        data["user_id"] = target_id
        data["enabled"] = True
        data["history"] = {}  # 核心改动：用字典记录每天的完成状态
        data["last_alert_date"] = ""

        all_reminders.append(data)
        save_json(REMINDERS_FILE, all_reminders)
        return jsonify({"status": "success"})

    user_reminders = [r for r in all_reminders if r.get("user_id") == target_id]
    return jsonify(user_reminders)


@app.route("/api/reminders/<int:index>", methods=["DELETE"])
def delete_reminder(index):
    if "user" not in session: return jsonify({"status": "error"})
    target_id = get_target_id(session["user"])
    all_reminders = load_json(REMINDERS_FILE)

    user_indices = [i for i, r in enumerate(all_reminders) if r.get("user_id") == target_id]
    if index < len(user_indices):
        all_reminders.pop(user_indices[index])
        save_json(REMINDERS_FILE, all_reminders)
        return jsonify({"status": "success"})
    return jsonify({"status": "error"})


# --- 检查提醒触发 API (全局弹窗核心逻辑) ---
@app.route("/api/check", methods=["GET"])
def check_api():
    if "user" not in session: return jsonify([])
    user_id = session["user"]["id"]

    now = datetime.now()
    current_time = now.strftime("%H:%M")
    current_date = now.strftime("%Y-%m-%d")

    all_reminders = load_json(REMINDERS_FILE)
    due_reminders = []

    for r in all_reminders:
        if r.get("user_id") == user_id and r.get("enabled"):
            if r.get("time_hhmm") == current_time:
                # 每天只触发一次弹窗
                if r.get("last_alert_date") != current_date:
                    due_reminders.append(r)
                    r["last_alert_date"] = current_date
                    save_json(REMINDERS_FILE, all_reminders)

    return jsonify(due_reminders)


# --- 记录老人完成状态 API (写入 history 字典) ---
@app.route("/api/reminders/respond", methods=["POST"])
def respond_reminder():
    if "user" not in session: return jsonify({"status": "error"})
    data = request.json
    rem_id = data.get("id")
    status = data.get("status")  # 'completed' or 'missed'

    all_reminders = load_json(REMINDERS_FILE)
    current_date = datetime.now().strftime("%Y-%m-%d")

    for r in all_reminders:
        if r.get("id") == rem_id:
            if "history" not in r:
                r["history"] = {}
            r["history"][current_date] = status
            save_json(REMINDERS_FILE, all_reminders)
            return jsonify({"status": "success"})

    return jsonify({"status": "error", "message": "Reminder not found"})


# --- 护工专属：获取今日老人完成事项概览 (用于登录弹窗) ---
@app.route("/api/carer/notifications", methods=["GET"])
def carer_notifications():
    if "user" not in session or session["user"]["role"] != "carer":
        return jsonify([])

    target_id = session["user"].get("linked_elderly_id")
    current_date = datetime.now().strftime("%Y-%m-%d")
    all_reminders = load_json(REMINDERS_FILE)

    notifications = []
    for r in all_reminders:
        history = r.get("history", {})
        if r.get("user_id") == target_id and current_date in history:
            notifications.append({
                "name": r.get("name"),
                "dosage": r.get("dosage"),
                "status": history[current_date],
                "time": r.get("time_hhmm")
            })

    return jsonify(notifications)


# --- 登录/注册 ---
@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.json
    uid, pwd = data.get("id"), data.get("password")
    users = load_json(USERS_FILE, dict)

    if uid in users and users[uid]["password"] == pwd:
        user = users[uid]
        if user.get("role") == "elderly": user["role"] = "elder"
        session["user"] = user
        return jsonify({"status": "success", "user": user})
    return jsonify({"status": "error", "message": "Invalid ID or Password"})


@app.route("/api/auth/register", methods=["POST"])
def register():
    data = request.json
    uid = data.get("id")
    users = load_json(USERS_FILE, dict)

    if uid in users: return jsonify({"status": "error", "message": "User exists"})
    users[uid] = data
    save_json(USERS_FILE, users)
    return jsonify({"status": "success"})


if __name__ == "__main__":
    app.run(debug=True)